# Tarea para Claude Code — Actualizar y desplegar AURA

## Qué hay en este paquete
- `index.html` — la landing de AURA **ya construida y lista para producción**. Es un único archivo autocontenido (HTML + CSS + JS + imágenes embebidas, ~4.9 MB). No necesita build, assets externos ni dependencias.

## Objetivo
Reemplazar el `index.html` actual del sitio con esta versión, subir el cambio a GitHub y publicar en Vercel.

## Pasos

### 1. Localiza el repositorio
El repo del sitio ya existe localmente (es el que está conectado a Vercel). Si no sabes cuál es, búscalo:
```bash
# desde la carpeta donde vive el proyecto del sitio
git remote -v
```
El `index.html` a reemplazar suele estar en la raíz del repo o en `public/`. Confírmalo:
```bash
find . -maxdepth 2 -name index.html -not -path '*/node_modules/*'
```

### 2. Reemplaza el archivo
Copia el `index.html` de este paquete sobre el del repo (misma ruta que encontraste arriba). Ejemplo si está en la raíz:
```bash
cp /ruta/a/deploy_handoff/index.html ./index.html
```

### 3. Commit y push a GitHub
```bash
git add index.html
git commit -m "Actualiza landing AURA: reorg storytelling (producto primero), popup 10% exit-intent, imágenes WebP optimizadas, descuentos 5/10/15%, fotos en carrito"
git push origin main   # o la rama por defecto (master/main)
```

### 4. Publicar en Vercel
- **Si el repo está conectado a Vercel** (lo normal): el `git push` **dispara el deploy automáticamente**. No hay que hacer nada más — espera 1-2 min y verifica en el dashboard de Vercel o en la URL de producción.
- **Si prefieres/ necesitas deploy manual** con la CLI:
```bash
vercel --prod
```
(Si la CLI no está instalada: `npm i -g vercel` y luego `vercel login`.)

### 5. Verifica
Abre la URL de producción y confirma:
- El hero carga la imagen de producto morada.
- El orden es: hero → Capítulo 01 "Elige tu modelo" (productos) → Capítulo 02 "El problema".
- El popup del 10% salta con intención de salida (mueve el cursor fuera por arriba) una sola vez.
- El carrito muestra fotos de cada producto.
- En móvil el nav cabe (carrito como icono) y "Compara y decide" son tarjetas apiladas.

## Notas
- Es un sitio estático de **un solo archivo**. No hay framework, no hay `npm run build`. El deploy de Vercel solo sirve el `index.html`.
- Si el proyecto de Vercel usa una carpeta de salida distinta (`public/`, `dist/`), coloca el `index.html` ahí en el paso 2.
- La fuente editable de este diseño vive en el proyecto de diseño como `AURA Ventas v2.dc.html`; este `index.html` es su versión compilada y autocontenida para hosting.
